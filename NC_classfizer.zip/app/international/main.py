from app.international.model import *

# функция взаимодействия back + ML
def predict(input_path, output_path, flag = 0):
    if flag: model_training()
    get_predictions(input_path).to_csv(output_path)