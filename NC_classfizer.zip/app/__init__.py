from flask import Flask
from config import Config

# initializing and configuring the app
app = Flask(__name__)
app.config.from_object(Config)

# importing routes
from app import routes