import pandas as pd
import os
import csv


# класс различных вспомогательных функций
class Tools():
    # удаление лишнего столбца
    def decrease_csv(self):
        # Чтение CSV файла
        df = pd.read_csv(os.path.join("app/static/", "table_res.csv"))
        df.drop([df.columns[0]], axis=1, inplace=True)
        df.to_csv(os.path.join("app/static/", "table_res.csv"), index=False)


    # копия файла
    def copy_file(self):
        df = pd.read_csv(os.path.join("app/static/", "table_res.csv"))
        df.to_csv(os.path.join("app/static/", "table_res_copy.csv"), index=False)        


    # фильтрация + сортировка
    def process_csv(self, input_file, output_file, with_description=False):
        with open(input_file, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            filtered_data = []
            for row in reader:
                print("now the row (2): ", row)
                entry = {
                    "index": row["index"],
                    "Тема": row["Тема"].capitalize(),
                    "Тип оборудования": row["Тип оборудования"].upper() if row["Тип оборудования"].lower() == "схд" else row["Тип оборудования"].capitalize(),
                    "Точка отказа": row["Точка отказа"].capitalize(),
                    "Серийный номер": row["Серийный номер"].capitalize(),
                }
                if with_description:
                    entry["Описание"] = row["Описание"]  # Добавляем "Описание" без capitalize
                filtered_data.append(entry)
            
        if len(filtered_data) == 1:
            # filtered_data += filtered_data            
            sorted_data = filtered_data
            print(sorted_data, 0)
        else:
            sorted_data = sorted(filtered_data, key=lambda x: int(x["index"]))
            print(sorted_data, 1)

        fieldnames = ["index", "Тема"]
        if with_description:
            fieldnames.append("Описание")
        fieldnames += ["Тип оборудования", "Точка отказа", "Серийный номер"]

        with open(output_file, mode='w', encoding='utf-8', newline='') as file:
            writer = csv.DictWriter(file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(sorted_data)


    # предобработка для фильтрации и сортировки
    def update_table(self, request, addfilters=[]):
        if addfilters == []:
            # Получение фильтров из запроса
            filters = request.json.get('filters', [])
        else:
            filters = addfilters
        print(filters)
        # Списки для различных типов фильтров
        filt_type = []
        filt_status = []
        
        # Определение возможных фильтров для типа устройства и статуса
        type_filters = {'Сервер', 'Ноутбук', 'СХД'}
        status_filters = {'Полная', 'Неполная'}
        
        # Разделение фильтров на типы и статусы
        filt_type = [f for f in filters if f in type_filters]
        filters = [f for f in filters if f not in type_filters]
        filt_status = [f for f in filters if f in status_filters]
        filters = [f for f in filters if f not in status_filters]
        
        # Оставшиеся фильтры считаем фильтрами "поломок"
        filt_break = filters[:]
        if 'Cервер' in filt_break: 
            filt_break.remove('Cервер')
            filt_break.append('Сервер')
        
        # Очищаем списки фильтров, если в них содержатся все возможные значения
        if len(filt_type) == len(type_filters):
            filt_type = []
        if len(filt_status) == len(status_filters):
            filt_status = []
        if len(filt_break) == 16: 
            filt_break = []
        
        # Чтение и фильтрация данных из CSV-файла
        with open(os.path.join("app/static/", "table_res.csv"), newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            header = next(reader)
            results = [header] + [row for row in reader]
        print(results)
        # Фильтрация данных по заданным фильтрам
        filtered_results = [results[0]]  # Добавляем заголовок
        print(filtered_results)
        for row in results[1:]:
            print("now the row: ", row)
            if filt_type and row[-3] not in filt_type:
                continue
            if filt_break and row[-2] not in filt_break:
                continue
            if filt_status and filt_status[-1] == 'Неполная':
                if "Уточнить" not in [row[-1], row[-2], row[-3]]:
                    continue
            elif filt_status and filt_status[-1] == 'Полная':
                if "Уточнить" in [row[-1], row[-2], row[-3]]:
                    continue
            filtered_results.append(row)
        if len(filtered_results) == 1:
            filtered_results.append(["", "", "", "", ""])
        # Преобразование отфильтрованных данных в DataFrame и возврат в формате JSON
        print(filtered_results)
        df = pd.DataFrame(filtered_results[1:], columns=filtered_results[0])
        df.to_csv(os.path.join("app/static/", "table_res_copy.csv"), sep=",", encoding="utf-8")
        self.process_csv(os.path.join("app/static/", "table_res_copy.csv"), os.path.join("app/static/", "table_res_copy.csv"))
        return df.to_json(orient='records')


    # обработчик csv перед сортировкой и фильтрацией
    def filter_and_process_csv(self, index_file, data_file, output_file):
        with open(index_file, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            indexes = {row["index"] for row in reader}
            print(indexes)
        
        with open(data_file, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            filtered_data = [
                row for row in reader if row["index"] in indexes
            ]

        with open(output_file, mode='w', encoding='utf-8', newline='') as temp_file:
            fieldnames = reader.fieldnames
            writer = csv.DictWriter(temp_file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(filtered_data)

        self.process_csv(output_file, output_file, with_description=True)
        return indexes


    # получение записи по индексу
    def get_record_by_index(self, file_path, index_value):
        with open(file_path, mode='r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            # Поиск строки с нужным индексом
            for row in reader:
                if row["index"] == str(index_value): 
                    return {
                        "Тема": row["Тема"],
                        "Описание": row["Описание"],
                        "Тип оборудования": row["Тип оборудования"],
                        "Точка отказа": row["Точка отказа"],
                        "Серийный номер": row["Серийный номер"],
                        "Рекомендация": row["recommendation"]
                    }
        return {
            "Тема": None,
            "Описание": None,
            "Тип оборудования": None,
            "Точка отказа": None,
            "Серийный номер": None,
            "Рекомендации": None
        }