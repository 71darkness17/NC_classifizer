from app import app
from app.tools import Tools
from app.international import main as model

from flask import render_template, flash, redirect, session, url_for, request, jsonify, make_response, abort, send_from_directory, send_file

import os
import io

import pandas as pd


# страница результата (таблицы)
@app.route("/result", methods=["GET"])
def result():
    return render_template("result.html", css=url_for("static", filename="styles.css"), csv=url_for("static", filename="table_res.csv"), filename="table_res.csv")


# get-запрос для получения обновленной таблицы
@app.route("/data", methods=["GET"])
def data():
    return send_from_directory("static", "table_res.csv")


# post-запрос выгрузки таблицы в CSV
@app.route('/export', methods=['POST'])
def download_csv():
    tools = Tools()
    if os. path. exists(os.path.join("app/static", "table_res_copy.csv")): 
        directory = os.path.join("app/static", "table_res_copy.csv")
    else: 
        directory = os.path.join("app/static", "table_res.csv")
    tools.filter_and_process_csv(directory, os.path.join("app/static", "table.csv"), os.path.join("app/static", "table_filtered.csv"))

    return send_file(os.path.join("static", "table_filtered.csv"), mimetype="application/octet-stream")


# страница после кнопки "посмотреть"
@app.route("/intelligence", methods=["GET"])
def intelligence():
    a = request.args.get("rowId", type=int)
    print(a)    
    return render_template('information.html', data=Tools().get_record_by_index(os.path.join("app/static", "table.csv"), a))


# post-запрос обновления таблицы
@app.route("/update", methods=["POST"])
def update():
    a = request.json
    print(a)
    tools = Tools()
    tools.copy_file()
    return tools.update_table(request)


# получение данных с формы
@app.route("/post", methods=["POST"])
def post():
    # сохранение и обработка файла
    file = request.files["file"]
    file.save(os.path.join("app/static", "table.csv"))
    model.predict(os.path.join("app/static", "table.csv",), os.path.join("app/static", "table.csv"))
    tools = Tools()
    tools.process_csv(os.path.join("app/static", "table.csv"), os.path.join("app/static", "table_res.csv"))
    return redirect(url_for("result"))


# главная страница
@app.route("/")
@app.route("/index")
def index():
    return render_template("index.html", css=url_for("static", filename="styles.css"))


# страница разработчиков
@app.route("/developers")
def devs():
    return render_template("developers.html", css=url_for("static", filename="styles.css"), developers=[url_for("static", filename="developer{}.jpg".format(i + 1)) for i in range(5)])


# обработка обращения к несуществующей таблице
@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({"error": "Not found"}), 404)


# шаблон для api через json
@app.route("/api/post/json", methods=["POST"])
def api_post_json():
  if not request.json or not "title" in request.json:
      abort(400)
  print(request.json)

  # do smt
  file_path = os.path.join("files/", "result.csv")
  return 1 # send_file(file_path, mimetype="application/octet-stream")


# api через csv файл
@app.route("/api/post/file", methods=["POST"])
def api_post_file():
    device_type = []
    fail_point = []
    status = []

    # словари значений
    devices = {
        0: "Ноутбук",
        1: "Сервер",
        2: "СХД"
    }

    fails = {
        0: "Консультация",
        1: "Аккумулятор",
        2: "Блок питания",
        3: "Вентилятор",
        4: "Динамики",
        5: "Диск",
        6: "Камера",
        7: "Клавиатура",
        8: "Корпус",
        9: "Материнская плата",
        10: "Оперативная память",
        11: "Программное обеспечение",
        12: "Cервер",
        13: "Jack",
        14: "SFP модуль",
        15: "Wi-fi модуль"
    }

    statuses = {
        1: "Полная",
        0: "Неполная"
    }

    # сбор фильтров
    if "device_type" in request.args.keys():
        device_type = [devices[int(i)] for i in request.args.get("device_type").split(",")]
    if "fail_point" in request.args.keys():
        fail_point = [fails[int(i)] for i in request.args.get("fail_point").split(",")]
    if "status" in request.args.keys():
        status = [statuses[int(i)] for i in request.args.get("status").split(",")]

    print(device_type, fail_point, status)

    filters = device_type + fail_point + status

    # сохранение файла пользователя
    file = request.files["file"]
    if file.filename == "":
        abort(400)
    file.save(os.path.join("app/static", "table.csv"))

    # обработка csv
    tools = Tools()

    model.predict(os.path.join("app/static", "table.csv",), os.path.join("app/static", "table.csv"))

    tools.process_csv(os.path.join("app/static", "table.csv"), os.path.join("app/static", "table_res.csv"))
    tools.update_table({}, addfilters=filters)

    # отправка csv
    file_path = os.path.join("static", "table_res_copy.csv")

    return send_file(file_path, mimetype="application/octet-stream")