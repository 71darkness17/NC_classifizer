import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from tensorflow.keras.models import Model, load_model
from tensorflow.keras.layers import Input, Embedding, LSTM, Dense, Dropout, Bidirectional, GlobalMaxPooling1D
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
import tensorflow as tf
from app.international.DataProcess import *

maxlen = 256
permitted = ['ноутбук', 'сила', 'pack', 'добрый', 'disk', 'работать', 'день', 'неисправность', 'сервер',
             'устройство', 'enclosure', 'экран', 'зарядный', 'online', 'show', 'disks', 'просить', 'ремонт',
             'state', 'проблема', 'питание', 'полоса', 'гарантийный', 'failed', 'type', 'диск', 'model', 'critical',
             'перестать', 'bios', 'вложение', 'заявка', 'драйвер', 'порт', 'storage', 'hardwarefailure', 'просьба',
             'коллега', 'блок', 'включаться', 'ошибка', 'описание', 'system', 'после', 'dd203', 'матрица', 'мерцание',
             'seagate', 'корректно', 'замена', 'alerts', 'unable', 'access', 'обновление', 'выйти', 'строй', 'неисправный',
             'появиться', 'открыть', 'ca01', 'номер', 'error', 'dimm', 'след', 'number', 'sase', 'другой', 'перезагрузка',
             'версия', 'быть', 'мерцать', 'dd503', 'time', 'монитор', 'серийный', 'p0(active', 'система', 'пользователь',
             'работа', 'звук', 'кнопка', 'post', '1135g7', 'модуль', 'заменить', 'кулер', 'принять', 'есть', 'фото', 'current',
             'severity', 'class', 'object', 'message', 'active', 'spare', 'capacity', 'подключение', 'hdmi', 'dd9800', 'модель',
             'физический', 'весь', 'аппаратный', 'через', 'there', 'полный', 'включение', 'дисплей', 'dd202', 'мочь', 'лог',
             'спасибо', 'воздействие', 'время', 'подключить', 'заряжаться', 'охлаждение', 'информация', 'часть', 'firmware',
             'загрузка', 'изображение', 'появляться', 'только', 'память', 'threshold', 'запрос', 'name', 'второй', 'один',
             'процесс', 'кейс', 'dd401', 'dd204', 'sila', 'зарядка', 'идти', 'системный', 'повреждение', 'вентилятор',
             'дополнительный', 'нижний', 'скорее', 'row(disk', 'legend', 'count', 'installed', 'total', 'последний']

# Создание словаря для ключевых слов
permitted_to_index = {word: idx + 1 for idx, word in enumerate(permitted)}  # Индексация с 1
permitted_to_index["<OOV>"] = len(permitted) + 1

# Функция для преобразования текста в последовательности чисел с использованием вашего словаря
def text_to_sequence(text):
    # Приводим текст к нижнему регистру
    text = text.lower()
    # Разбиваем текст на слова
    words = text.split()
    # Преобразуем каждое слово в индекс, если оно есть в словаре, иначе заменяем на <OOV>
    sequence = [permitted_to_index.get(word, permitted_to_index["<OOV>"]) for word in words]
    return sequence

def model_training():
    # Шаг 1. Подготовка данных
    # Загружаем данные через функцию preprocess
    df = preprocess('train_data.csv')[0]
    # Убираем столбцы, которые не будем использовать при обучении
    df.drop(columns = ['index', 'Тема', 'Описание', 'Серийный номер', 'is_full'], inplace = True)
    # Преобразование текста из столбца "Description" в последовательности чисел
    X = df['Description'].apply(lambda x: text_to_sequence(x))
    # Паддинг последовательности, чтобы они имели одинаковую длину
    X = tf.keras.preprocessing.sequence.pad_sequences(X, padding = 'post', maxlen = maxlen)
    # One-hot преобразование категориальных меток
    y_equipment = to_categorical(df['Тип оборудования'])
    y_failure_point = to_categorical(df['Точка отказа'])

    # Шаг 2. Разделение на тренировочную и тестовую выборки
    X_train, X_test, y_train_equipment, y_test_equipment, y_train_failure, y_test_failure = train_test_split(
        X, y_equipment, y_failure_point, test_size = 0.2, random_state = 80)

    # Шаг 3. Построение модели
    input_layer = Input(shape = (X.shape[1],))  # Длина последовательности (максимальная длина текста)

    # Эмбеддинг
    embedding = Embedding(input_dim = 151, output_dim = 64)(input_layer)

    # Добавление Bidirectional LSTM для улучшения обработки контекста
    lstm_1 = Bidirectional(LSTM(64, return_sequences = True))(embedding)
    dropout_1 = Dropout(0.5)(lstm_1)  # Dropout для предотвращения переобучения

    # Пулинг после первого LSTM (GlobalMaxPooling1D)
    pooling_1 = GlobalMaxPooling1D()(dropout_1)

    # Второй LSTM слой (без return_sequences, так как он не нужен для пулинга)
    lstm_2 = LSTM(32)(dropout_1)  # Второй LSTM слой для улучшения извлечения признаков

    # Объединение слоев для классификации
    concatenated = tf.keras.layers.concatenate([pooling_1, lstm_2])

    # Полносвязные слои для классификации по 2 категориям
    equipment_output = Dense(y_equipment.shape[1], activation = 'softmax', name = 'equipment')(concatenated)
    failure_output = Dense(y_failure_point.shape[1], activation = 'softmax', name = 'failure_point')(concatenated)

    # Компилируем модель
    model = Model(inputs = input_layer, outputs = [equipment_output, failure_output])

    # Компилируем модель с метриками для каждого выхода по имени
    model.compile(optimizer = Adam(learning_rate = 0.001),
                loss = ['categorical_crossentropy', 'categorical_crossentropy'],
                metrics = {'equipment': ['accuracy'], 'failure_point': ['accuracy']})
    
    # Создаем коллбек ReduceLROnPlateau
    reduce_lr = ReduceLROnPlateau(
        monitor = 'val_loss',      # Отслеживаем валидационную потерю
        factor = 0.1,              # Уменьшаем скорость обучения на 10%
        patience = 5,              # Если валидационная потеря не улучшается в течение 5 эпох, уменьшаем lr
        min_lr = 1e-6,             # Минимальная скорость обучения
        verbose = 1                # Выводим сообщения при изменении lr
    )

    # Создаем коллбек EarlyStopping
    early_stopping = EarlyStopping(
        monitor = 'val_loss',        # Следим за валидационной потерей
        patience = 15,               # Останавливаем обучение, если нет улучшений 10 эпох подряд
        restore_best_weights = True, # Восстанавливаем веса модели с наилучшей валидационной потерей
        verbose = 1                   # Выводим сообщения о ранней остановке
    )

    # Обучаем модель, передавая коллбек в параметр callbacks
    history = model.fit(
        X_train,
        [y_train_equipment, y_train_failure],  # Целевые метки для двух задач
        epochs = 100,
        batch_size = 16,
        validation_split = 0.2,    # Используем 20% данных для валидации
        callbacks = [early_stopping, reduce_lr] # Включаем коллбек для ранней остановки
    )

    # Шаг 5. Оценка точности модели
    y_pred_equipment, y_pred_failure = model.predict(X_test)
    # Преобразуем предсказания в классы
    y_pred_equipment = np.argmax(y_pred_equipment, axis = 1)
    y_pred_failure = np.argmax(y_pred_failure, axis = 1)

    # Точность для обеих категорий
    accuracy_equipment = accuracy_score(np.argmax(y_test_equipment, axis = 1), y_pred_equipment)
    accuracy_failure = accuracy_score(np.argmax(y_test_failure, axis = 1), y_pred_failure)
    print(f"Точность по Типу оборудования: {accuracy_equipment * 100:.2f}%")
    print(f"Точность по Точке отказа: {accuracy_failure * 100:.2f}%")

    model.save('model.keras')
    return history

def get_predictions(file_path):
    model = load_model('app/international/model.keras')
    df, serials = preprocess(file_path)
    indexes = df['index']
    topics = df['Тема']
    descriptions = df['Описание']
    completenesses = df['is_full']
    # Убираем столбцы, которые не будем использовать при обучении
    df.drop(columns = ['index', 'Тема', 'Описание', 'is_full'], inplace = True)
    # Преобразование текста из столбца "Description" в последовательности чисел
    X = df['Description'].apply(lambda x: text_to_sequence(x))
    # Паддинг последовательности, чтобы они имели одинаковую длину
    X = tf.keras.preprocessing.sequence.pad_sequences(X, padding = 'post', maxlen = maxlen)
    pred_equipment, pred_failure = model.predict(X)
    # Преобразуем предсказания в классы
    pred_equipment = np.argmax(pred_equipment, axis = 1)
    pred_failure = np.argmax(pred_failure, axis = 1)
    equipment = {0: "Ноутбук", 1: "Сервер", 2: "СХД"}
    failure = {0 : 'Аккумулятор',
        1 : 'Блок питания',
        2 : 'Вентилятор',
        3 : 'Динамики',
        4 : 'Диск',
        5 : 'Камера',
        6 : 'Клавиатура',
        7 : 'Корпус',
        8 : 'Материнская плата',
        9 : 'Матрица',
        10 : 'Оперативная память',
        11 : 'Программное обеспечение',
        12 : 'Сервер',
        13 : 'Jack',
        14 : 'SFP модуль',
        15 : 'Wi-fi модуль'}
    pred_equipment = list(map(lambda x: equipment[x], pred_equipment))
    pred_failure = list(map(lambda x: failure[x], pred_failure))

    df = pd.DataFrame(zip(indexes, topics, descriptions, pred_equipment, pred_failure, serials, completenesses), columns = ["index", "Тема", "Описание", "Тип оборудования", "Точка отказа", "Серийный номер", "is_full"])
    recommend_all(df)
    return df